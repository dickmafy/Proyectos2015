<?php
include "config.php";
if(isset($_GET['id'])):
  $hap = unlink('upload/'.$_GET['nm']);
  if($hap){
     $stmt = $mysqli->prepare("DELETE FROM upload_data WHERE id_upload=?");
     $stmt->bind_param('s', $id);

     $id = $_GET['id'];

     if($stmt->execute()):
          echo "<script>location.href='index.php'</script>";
     else:
          echo "<script>alert('".$stmt->error."')</script>";
     endif;
  } else{
    echo "<script>alert('No Delete File From Harddisk')</script>";
    echo "<script>location.href='index.php'</script>";
  }
endif;
?>