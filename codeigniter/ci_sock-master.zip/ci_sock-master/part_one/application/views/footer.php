<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="<?php echo base_url();?>/js/vendor/jquery-1.9.0.min.js"><\/script>')</script>

<script src="<?php echo base_url();?>/assets/js/vendor/bootstrap.min.js"></script>

<script src="<?php echo base_url();?>/assets/js/main.js"></script>
</body>
</html>
