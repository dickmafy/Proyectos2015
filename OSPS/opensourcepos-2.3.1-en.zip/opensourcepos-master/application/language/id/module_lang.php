<?php
$lang['module_home'] = 'Beranda';

$lang['module_customers'] = 'Pelanggan';
$lang['module_customers_desc'] = 'Tambah, Rubah, Hapus, dan Cari Pelanggan ';

$lang['module_suppliers'] = 'Pemasok';
$lang['module_suppliers_desc'] = 'Tambah, Rubah, Hapus, dan Cari Pemasok';

$lang['module_employees'] = 'Karyawan';
$lang['module_employees_desc'] = 'Tambah, Rubah, Hapus, dan Cari Karyawan';

$lang['module_sales'] = 'Penjualan';
$lang['module_sales_desc'] = 'Proses Penjualan dan Retur';

$lang['module_reports'] = 'Laporan';
$lang['module_reports_desc'] = 'Lihat dan Cetak Laporan';

$lang['module_items'] = 'Item Barang';
$lang['module_items_desc'] = 'Tambah, Rubah, Hapus, dan Cari Item Barang';

$lang['module_config'] = 'Konfigurasi';
$lang['module_config_desc'] = 'Ubah Konfigurasi Toko';

$lang['module_receivings'] = 'Penerimaan';
$lang['module_receivings_desc'] = 'Proses Order Penerimaan Barang Masuk';

$lang['module_giftcards'] = 'Gift Card';
$lang['module_giftcards_desc'] = 'Tambah, Rubah, Hapus dan Cari Gift Card';

$lang['module_item_kits'] = 'Item Paket';
$lang['module_item_kits_desc'] = 'Tambah, Rubah, Hapus dan Cari Item Paket';

?>
