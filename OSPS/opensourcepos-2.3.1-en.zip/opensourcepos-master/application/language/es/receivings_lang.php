<?php
$lang['recvs_register'] = 'Entrada de Artículos';
$lang['recvs_mode'] = 'Modo de Entradas';
$lang['recvs_receiving'] = 'Recibir';
$lang['recvs_return'] = 'Devolver';
$lang['recvs_total'] = 'Total';
$lang['recvs_cost'] = 'Costo';
$lang['recvs_quantity'] = 'Cant.';
$lang['recvs_discount'] = 'Descuento %';
$lang['recvs_edit'] = 'Editar';
$lang['recvs_new_supplier'] = 'Nuevo Proveedor';
$lang['recvs_supplier'] = 'Proveedor';
$lang['recvs_select_supplier'] = 'Seleccionar Proveedor (Opcional)';
$lang['recvs_start_typing_supplier_name'] = 'Empieza a escribir el nombre del proveedor...';
$lang['recvs_unable_to_add_item'] = 'No se puede agregar el artículo a la entrada';
$lang['recvs_error_editing_item'] = 'Error al editar artículo';
$lang['recvs_receipt'] = 'Recibo de Entrada';
$lang['recvs_complete_receiving'] = 'Terminar';
$lang['recvs_confirm_finish_receiving'] = '¿Estás seguro(a) de querer procesar esta entrada? Ésto no puede ser deshecho.';
$lang['recvs_confirm_cancel_receiving'] = '¿Estás seguro(a) de querer limpiar esta entrada? Todos los artículos serán limpiados.';
$lang['recvs_find_or_scan_item'] = 'Encontrar/Escanear Artículo';
$lang['recvs_find_or_scan_item_or_receipt'] = 'Encontrar/Escanear Artículo o Entrada';
$lang['recvs_id'] = 'ID de Entrada';
$lang['recvs_item_name'] = 'Nombre del Artículo';
$lang['receivings_transaction_failed'] = 'Las Transacciones de Entrada Fallaron';
?>
