<?php
$lang['customers_new']='ลูกค้าใหม่'; 
$lang['customers_customer']='ลูกค้า';  
$lang['customers_update']='แก้ไขข้อมูลลูกค้า'; 
$lang['customers_confirm_delete']='ยืนยันลบข้อมูลลูกค้า?'; 
$lang['customers_none_selected']='คุณยังไม่ได้ทำการเลือกลูกค้า'; 
$lang['customers_error_adding_updating'] = 'แก้ไขข้อมูลลูกค้าผิดพลาด'; 
$lang['customers_successful_adding']='คุณได้ทำการเพิ่มลูกค้าเรียบร้อยแล้ว'; 
$lang['customers_successful_updating']='คุณได้ทำการแก้ไขข้อมูลลูกค้าเรียบร้อยแล้ว'; 
$lang['customers_successful_deleted']='คุณได้ทำการลบข้อมูลเรียบร้อยแล้ว'; 
$lang['customers_one_or_multiple']='ลูกค้า'; 
$lang['customers_cannot_be_deleted']='ไม่สามารลบลูกค้าที่ถูกเลือก, ลูกค้าที่ถูกเลือกถูขายไปแล้ว.';
$lang['customers_basic_information']='ข้อมูลลูกค้า';
$lang['customers_account_number']='บัญชี #';
$lang['customers_taxable']='ต้องเสียภาษี';
?>
<?php
$lang['customers_new']='ลูกค้าใหม่'; 
$lang['customers_customer']='ลูกค้า';  
$lang['customers_update']='แก้ไขข้อมูลลูกค้า'; 
$lang['customers_confirm_delete']='ยืนยันลบข้อมูลลูกค้า?'; 
$lang['customers_none_selected']='คุณยังไม่ได้ทำการเลือกลูกค้า'; 
$lang['customers_error_adding_updating'] = 'แก้ไขข้อมูลลูกค้าผิดพลาด'; 
$lang['customers_successful_adding']='คุณได้ทำการเพิ่มลูกค้าเรียบร้อยแล้ว'; 
$lang['customers_successful_updating']='คุณได้ทำการแก้ไขข้อมูลลูกค้าเรียบร้อยแล้ว'; 
$lang['customers_successful_deleted']='คุณได้ทำการลบข้อมูลเรียบร้อยแล้ว'; 
$lang['customers_one_or_multiple']='ลูกค้า'; 
$lang['customers_cannot_be_deleted']='ไม่สามารลบลูกค้าที่ถูกเลือก, ลูกค้าที่ถูกเลือกถูขายไปแล้ว.';
$lang['customers_basic_information']='ข้อมูลลูกค้า';
$lang['customers_account_number']='บัญชี #';
$lang['customers_taxable']='ต้องเสียภาษี';
?>
