<?php
$lang['login_login'] = 'Login';
$lang['login_username'] = 'Gebruiker';
$lang['login_password'] = 'Paswoord';
$lang['login_go'] = 'Verstuur';
$lang['login_invalid_username_and_password'] = 'Ongeldige gebruiker/paswoord';
$lang['login_welcome_message'] = 'Welkom in deze module. Voer gebruikersnaam en paswoord in om verder te gaan.';
?>
