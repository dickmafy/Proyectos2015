<?php
$lang['error_no_permission_module'] = 'У вас нет разрешения на доступ к модуля называется';
$lang['error_unknown'] = 'неизвестный';
?>