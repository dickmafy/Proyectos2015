<?php
$lang['module_home'] = 'Дома';

$lang['module_customers'] = 'Клиенты';
$lang['module_customers_desc'] = 'Добавление, обновление, удаление и поиск клиентов';

$lang['module_suppliers'] = 'Поставщики';
$lang['module_suppliers_desc'] = 'Добавление, обновление, удаление и поиск suppliers';

$lang['module_employees'] = 'Сотрудники';
$lang['module_employees_desc'] = 'Добавление, обновление, удаление и поиск сотрудники';

$lang['module_sales'] = 'Продажа';
$lang['module_sales_desc'] = 'Процесс продажи и возвращается';

$lang['module_reports'] = 'Отчеты';
$lang['module_reports_desc'] = 'Просмотр и создание отчетов';

$lang['module_items'] = 'Товары';
$lang['module_items_desc'] = 'Добавление, обновление, удаление и поиск товары';

$lang['module_config'] = 'Конфигурацию магазина';
$lang['module_config_desc'] = 'Изменить конфигурацию магазина';

$lang['module_receivings'] = 'получении';
$lang['module_receivings_desc'] = 'Процесс покупки заказов';

$lang['module_giftcards'] = 'Подарочные карты';
$lang['module_giftcards_desc'] = 'Добавление, обновление, удаление и поиск подарочные карты';

$lang['module_item_kits'] = 'товара комплекти';
$lang['module_item_kits_desc'] = 'Добавление, обновление, удаление и поиск товара комплекти';

?>
