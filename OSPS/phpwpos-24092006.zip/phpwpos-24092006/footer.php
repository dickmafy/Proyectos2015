<?php
/*
  PHPWPos, Open Source Point-Of-Sale System
  http://phpwpos.ptwebserve.com

  Copyright (c) 2006 Mois�s Sequeira

  Released under the GNU General Public License
*/

?>

<table id="footer" cellspacing="0" width="100%">
<TR><TD align="center">2006 &copy; Mois�s Sequeira<br><a href="http://www.ptwebserve.com/phpwpos">http://www.ptwebserve.com/phpwpos</a></TD></TR>
</table>
