<?php
/*
  PHPWPos, Open Source Point-Of-Sale System
  http://phpwpos.ptwebserve.com

  Copyright (c) 2006 Moisés Sequeira

  Released under the GNU General Public License
*/

$languages = array('English' => "english", "Portugu&ecirc;s" => "portuguese", "Deutsch" => "german");

?>

