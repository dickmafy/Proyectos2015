<?php
/*
  PHPWPos, Open Source Point-Of-Sale System
  http://phpwpos.ptwebserve.com

  Copyright (c) 2006 Moisés Sequeira

  Released under the GNU General Public License
*/
?>

<table id="header" cellspacing="0" width="100%">
<TR><TD><h4>&nbsp;PHPWPOS</h4><small>&nbsp;&nbsp;&nbsp;The opensource Point of Sale System</small><br><br></TD><TD align="right" valign="bottom"><?php echo date("d-m-Y"); ?></TD></TR>
</table>
