Angular Crud
======================

A small CRUD application using AngularJS and Slim PHP framework.

Requirements:
  * <a href="http://angularjs.org/">AngularJS</a>
  * <a href="http://www.slimframework.com/">Slim Framework</a>