<?php
return array (
  'template' => 'simple',
  'baseControllerClass' => 'Controller',
);
