$(function(){
	$(".chosen-select,.chosen-multiple-select").chosen({allow_single_deselect:true});	
});